import UIKit

var num = 10

num %= 10

num = num + 10

num -= 5

print(num)


let name = "Pooya"
let lastName = "Taheri"

let fullName = name + " " + lastName

print(fullName)

//-----------------------


10 <= 10

10 >= 9

10 == 10

"Hello" > "HEllo"

!true

!false






